var searchData=
[
  ['nextjob',['nextJob',['../class_task.html#aa442d4ae3c78da88410d8bda02781871',1,'Task']]]
];
