var searchData=
[
  ['absolute_5fdeadline',['absolute_deadline',['../struct_job.html#a5c95362dd923d046d3da1c62217ec08d',1,'Job']]]
];
