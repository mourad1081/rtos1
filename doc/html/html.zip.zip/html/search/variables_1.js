var searchData=
[
  ['computation',['computation',['../struct_job.html#afbc9f6c82366d317d10ac403ba805058',1,'Job']]]
];
