var searchData=
[
  ['deadline',['deadline',['../struct_job.html#a664acf70eb061af09753297141a3f6e8',1,'Job::deadline()'],['../class_task.html#abba9a3869e42d4bcbabd14d092b9b51e',1,'Task::deadline()']]]
];
