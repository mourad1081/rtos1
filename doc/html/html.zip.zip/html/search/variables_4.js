var searchData=
[
  ['max',['max',['../struct_interval.html#ac0483b774729a808ef96e2c46d7de805',1,'Interval']]],
  ['min',['min',['../struct_interval.html#a206676b17fade85c8a4d2f7eb31f5268',1,'Interval']]]
];
