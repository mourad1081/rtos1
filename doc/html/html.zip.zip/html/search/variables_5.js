var searchData=
[
  ['nbdesiredprocessors',['nbDesiredProcessors',['../struct_schedule_infos.html#aa3f3cc2b4aa3de3ade48bbc485c3f719',1,'ScheduleInfos']]],
  ['nbidleperprocessor',['nbIdlePerProcessor',['../struct_schedule_infos.html#ac79734ffe10273e84af14b6eb88f2670',1,'ScheduleInfos']]],
  ['nbidletotal',['nbIdleTotal',['../struct_schedule_infos.html#ab8410d4a51f228e8fa41ac59002cea7b',1,'ScheduleInfos']]],
  ['nbpreemptionsperprocessor',['nbPreemptionsPerProcessor',['../struct_schedule_infos.html#a087ec47913531ba3ed2dc4f4aae2c020',1,'ScheduleInfos']]],
  ['nbpreemptionstotal',['nbPreemptionsTotal',['../struct_schedule_infos.html#ab0bb1a2db57c062809fab54e64461814',1,'ScheduleInfos']]],
  ['nbrequiredprocessors',['nbRequiredProcessors',['../struct_schedule_infos.html#acfdf9eefa175195bb50b2f925467352e',1,'ScheduleInfos']]],
  ['num',['num',['../class_task.html#abeded0321cfcb7f18849ec0fa0fb28da',1,'Task']]]
];
