var searchData=
[
  ['offset',['offset',['../class_task.html#a04ec883da83ec15168107e483a557a30',1,'Task']]]
];
