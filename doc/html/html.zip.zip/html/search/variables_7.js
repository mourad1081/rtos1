var searchData=
[
  ['parent',['parent',['../struct_job.html#a1690e49e73d4b304c1db2982cfbc91dd',1,'Job']]],
  ['period',['period',['../class_task.html#a8ca19e5db24e7bf12d5f4936e4eafb8f',1,'Task']]]
];
