var searchData=
[
  ['release',['release',['../struct_job.html#a0df904b1da2fb60f3d65862de57e1f28',1,'Job']]],
  ['remeaningcomputation',['remeaningComputation',['../struct_job.html#aa435576254c7418fbe0d3d4bc950c704',1,'Job']]]
];
