# Projet RTOS 1

Quasiment fini...
  
Ensuite, vous trouverez le fichier main.cpp dans lequel a déjà été implémenté le module taskGenerator et simM (en partie).
Il reste encore à faire simDM (à moitié) et studyDM. 

Pour compiler votre travail, il suffit juste de taper "make" dans le dosier courant en ligne de commande. C'est dans ce make que je définis la génération des tous les modules. Et j'active certains flags qui font en sorte que le main() redirige vers le bon module.
